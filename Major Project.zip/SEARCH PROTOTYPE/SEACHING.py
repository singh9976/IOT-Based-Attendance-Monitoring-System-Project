import re
f=open("FULL FETCH INFO.txt", "r")
f1=f.readlines()
for x in f1:
    ext= x.split("<br>")[0]
    #print(str(ext))

    #write only data in new file
    file=open("DATA.txt","a")
    file.write("\n" +str(ext))
    file.close()
g=input("WANT TO SEARCH THE DATA(Y/N):")

if(g=='Y'):
    z=input("BY DATE OR NAME OR BOTH (D/N/B):")
    if(z=="D"):
        u=input("Write the date <dd/mm/yyyy> : ")
        for line in f1:
            if re.match("(.*)"+ u+ "(.*)",line):
                
                file=open("DATE RESULT.txt","a+")
                file.write("\n" + line)
                file.close()
    if(z=="N"):
        r=input("Write the name or data for search :")
        for line in f1:
            if re.match("(.*)"+ r+ "(.*)",line):
                
                file=open("NAME RESULT.txt","a+")
                file.write("\n" + line)
                file.close()
    if(z=="B"):
        s=input("Write the date from <dd/mm/yyyy> :")
        for line in f1:
            if re.match("(.*)"+ s+ "(.*)",line):
                t=input("Write the date to <dd/mm/yyyy> :")
                for line in f1:
                    if re.match("(.*)"+ t+ "(.*)",line):
                        w=input("Write the Name :")
                        for line in f1:
                            if re.match("(.*)"+ w+ "(.*)",line):
                                file=open("BOTH RESULT.txt","a+")
                                file.write("\n" + line)
                                file.close()
                                print('done')
    
else:
    None
