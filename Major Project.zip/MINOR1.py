# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\Users\hp\Desktop\MINOR PROJECT\MINOR1.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import json
import requests
import urllib.request
import ssl
import re
import os
import time
import sys
from collections import Counter
from MINOR2 import Ui_Dialog

class Ui_MainWindow(object):
    def openWindow(self):
        
        self.window=QtWidgets.QDialog()
        self.ui=Ui_Dialog()
        self.ui.setupUi(self.window)
        self.window.show()
        
    def stop(self):
        sys.exit(app.exec_())
    

    def start(self):
        global a
        a=1
        global b
        b=1
        global c
        ssl._create_default_https_context = ssl._create_unverified_context
        webUrl  = urllib.request.urlopen('https://www.cloud.oytechnology.com/test3.php?uniq=4sgeghthl5watojy43x4&fetch')
        data1= webUrl.read()
        c=data1


        while(True):
            ssl._create_default_https_context = ssl._create_unverified_context
            webUrl  = urllib.request.urlopen('https://www.cloud.oytechnology.com/test3.php?uniq=4sgeghthl5watojy43x4&fetch')
            data= webUrl.read()
            
            
            if(data==c and c==data):
                
                if(b==1):    
                    data2 = str (data)
                    file=open("FULL FETCH INFO.txt","a")
                    file.write("\n" +data2)
                    file.close()
                    b=2
            if(data != c or c != data):
                data2 = str (data)
                file=open("FULL FETCH INFO.txt","a")
                file.write("\n"+ data2)
                file.close()
                c=data

    def clear(self):
        file1=open("FULL FETCH INFO.txt","r+")
        file1.truncate(0)



    
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(966, 719)
        MainWindow.setContextMenuPolicy(QtCore.Qt.NoContextMenu)
        MainWindow.setStyleSheet("")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.frame = QtWidgets.QFrame(self.centralwidget)
        self.frame.setEnabled(True)
        self.frame.setGeometry(QtCore.QRect(-10, 150, 1011, 571))
        self.frame.setContextMenuPolicy(QtCore.Qt.NoContextMenu)
        self.frame.setAcceptDrops(False)
        self.frame.setAccessibleDescription("")
        self.frame.setAutoFillBackground(False)
        self.frame.setStyleSheet("background-color: rgb(255, 255, 255);")
        self.frame.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.label_3 = QtWidgets.QLabel(self.frame)
        self.label_3.setGeometry(QtCore.QRect(210, 90, 781, 51))
        self.label_3.setStyleSheet("background-color: rgb(255, 244, 15);")
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(self.frame)
        self.label_4.setGeometry(QtCore.QRect(210, 180, 771, 51))
        self.label_4.setStyleSheet("background-color: rgb(255, 244, 15);")
        self.label_4.setObjectName("label_4")
        self.label_6 = QtWidgets.QLabel(self.frame)
        self.label_6.setGeometry(QtCore.QRect(210, 360, 771, 51))
        self.label_6.setStyleSheet("background-color: rgb(255, 244, 15);")
        self.label_6.setObjectName("label_6")
        self.label_5 = QtWidgets.QLabel(self.frame)
        self.label_5.setGeometry(QtCore.QRect(210, 270, 781, 51))
        self.label_5.setStyleSheet("background-color: rgb(255, 244, 15);")
        self.label_5.setObjectName("label_5")
        self.pushButton = QtWidgets.QPushButton(self.frame)
        self.pushButton.setGeometry(QtCore.QRect(40, 90, 141, 51))
        font = QtGui.QFont()
        font.setFamily("MS Shell Dlg 2")
        font.setPointSize(11)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.pushButton.setFont(font)
        self.pushButton.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.pushButton.setAutoFillBackground(False)
        self.pushButton.setStyleSheet("background-color: rgb(232, 62, 37);")
        self.pushButton.setObjectName("pushButton")
        self.pushButton.clicked.connect(self.start)
        self.pushButton_3 = QtWidgets.QPushButton(self.frame)
        self.pushButton_3.setGeometry(QtCore.QRect(40, 270, 141, 51))
        font = QtGui.QFont()
        font.setFamily("MS Shell Dlg 2")
        font.setPointSize(11)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.pushButton_3.setFont(font)
        self.pushButton_3.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.pushButton_3.setAutoFillBackground(False)
        self.pushButton_3.setStyleSheet("background-color: rgb(232, 62, 37);")
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_3.clicked.connect(self.openWindow)
        self.pushButton_4 = QtWidgets.QPushButton(self.frame)
        self.pushButton_4.setGeometry(QtCore.QRect(40, 360, 141, 51))
        font = QtGui.QFont()
        font.setFamily("MS Shell Dlg 2")
        font.setPointSize(11)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.pushButton_4.setFont(font)
        self.pushButton_4.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.pushButton_4.setAutoFillBackground(False)
        self.pushButton_4.setStyleSheet("background-color: rgb(232, 62, 37);")
        self.pushButton_4.setObjectName("pushButton_4")
        self.pushButton_4.clicked.connect(self.stop)
        self.pushButton_2 = QtWidgets.QPushButton(self.frame)
        self.pushButton_2.setGeometry(QtCore.QRect(40, 180, 141, 51))
        font = QtGui.QFont()
        font.setFamily("MS Shell Dlg 2")
        font.setPointSize(11)
        font.setBold(True)
        font.setItalic(False)
        font.setWeight(75)
        self.pushButton_2.setFont(font)
        self.pushButton_2.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.pushButton_2.setAutoFillBackground(False)
        self.pushButton_2.setStyleSheet("background-color: rgb(232, 62, 37);")
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_2.clicked.connect(self.clear)
        self.label_2 = QtWidgets.QLabel(self.frame)
        self.label_2.setGeometry(QtCore.QRect(-30, 510, 1021, 61))
        self.label_2.setStyleSheet("color: rgb(255, 255, 255);\n"
"background-color: rgb(34, 29, 61);")
        self.label_2.setObjectName("label_2")
        self.frame_2 = QtWidgets.QFrame(self.centralwidget)
        self.frame_2.setGeometry(QtCore.QRect(0, 0, 201, 221))
        self.frame_2.setAutoFillBackground(False)
        self.frame_2.setStyleSheet("\n"
"background-color: rgb(255, 255, 255);\n"
"background-image: url(:/newPrefix/download.jpg);\n"
"")
        self.frame_2.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_2.setObjectName("frame_2")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(80, -10, 1051, 231))
        self.label.setCursor(QtGui.QCursor(QtCore.Qt.PointingHandCursor))
        self.label.setAutoFillBackground(False)
        self.label.setStyleSheet("background-color: rgb(232, 62, 37);\n"
"color: rgb(12, 12, 12);")
        self.label.setOpenExternalLinks(True)
        self.label.setObjectName("label")
        self.frame.raise_()
        self.label.raise_()
        self.frame_2.raise_()
        MainWindow.setCentralWidget(self.centralwidget)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.label_3.setText(_translate("MainWindow", "<html><head/><body><p align=\"justify\"><span style=\" font-size:12pt;\">&lt;- This button will start the fetching of data from server to files</span></p></body></html>"))
        self.label_4.setText(_translate("MainWindow", "<html><head/><body><p align=\"justify\"><span style=\" font-size:12pt;\">&lt;- This button will clear all the data stored in file</span></p></body></html>"))
        self.label_6.setText(_translate("MainWindow", "<html><head/><body><p align=\"justify\"><span style=\" font-size:12pt;\">&lt;- This button will stop the receiving of the data from server to files</span></p></body></html>"))
        self.label_5.setText(_translate("MainWindow", "<html><head/><body><p align=\"justify\"><span style=\" font-size:12pt;\">&lt;- This button is used for counting the numbers of students</span></p></body></html>"))
        self.pushButton.setText(_translate("MainWindow", "START"))
        self.pushButton_3.setText(_translate("MainWindow", "COUNT"))
        self.pushButton_4.setText(_translate("MainWindow", "STOP"))
        self.pushButton_2.setText(_translate("MainWindow", "CLEAR"))
        self.label_2.setText(_translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:10pt; font-weight:600;\">DESIGNED AND MADE BY GROUP 1</span></p></body></html>"))
        self.label.setText(_translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><a href=\"https://www.aryacollege.in\"><span style=\" font-size:20pt; font-weight:600; text-decoration: underline; color:#000000;\">WELCOME TO THE ATTENDANCE FETCHING</span></a></p>\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><a href=\"https://www.aryacollege.in\"><span style=\" font-size:20pt; font-weight:600; text-decoration: underline; color:#000000;\">SOFTWARE</span></a></p></body></html>"))

import test

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())

